import{R as e}from"./vue-router-09fdc939.js";import{d as r,x as t}from"./runtime-core.esm-bundler-25b49e90.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
