import{d as e,e as t,be as a}from"./index-6c6ecfe0.js";const r=e({name:"ParentLayout",render(){return t(a,null,null)}});export{r as default};
