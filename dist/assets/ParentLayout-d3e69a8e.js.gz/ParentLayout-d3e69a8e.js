import{d as e,e as t,bg as a}from"./index-4147d4f8.js";const r=e({name:"ParentLayout",render(){return t(a,null,null)}});export{r as default};
