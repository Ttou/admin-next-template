import{R as e}from"./vue-router-67a58581.js";import{d as r,x as t}from"./runtime-core.esm-bundler-4761d9e9.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
