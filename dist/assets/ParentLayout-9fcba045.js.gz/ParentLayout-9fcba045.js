import{R as e}from"./vue-router-cbdf6480.js";import{d as r,x as t}from"./runtime-core.esm-bundler-487be079.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
