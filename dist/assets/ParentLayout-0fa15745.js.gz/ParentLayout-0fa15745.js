import{d as e,e as t,bg as a}from"./index-b2ad3f1e.js";const r=e({name:"ParentLayout",render(){return t(a,null,null)}});export{r as default};
