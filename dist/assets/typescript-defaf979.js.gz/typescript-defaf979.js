const a=t=>t;export{a as m};
