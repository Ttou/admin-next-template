import{R as e}from"./vue-router-8273c86d.js";import{d as r,p as t}from"./runtime-core.esm-bundler-a4e74cc4.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
