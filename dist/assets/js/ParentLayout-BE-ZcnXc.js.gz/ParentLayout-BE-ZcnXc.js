import{d as e,j as t,bd as a}from"./chunk-libs-CwqTQsJI.js";const r=e({name:"ParentLayout",render(){return t(a,null,null)}});export{r as default};
