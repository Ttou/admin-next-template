import{d as e,j as t,bI as a}from"./index-VnQc-Xww.js";const r=e({name:"ParentLayout",render(){return t(a,null,null)}});export{r as default};
