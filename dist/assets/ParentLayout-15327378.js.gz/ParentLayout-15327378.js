import{R as e}from"./vue-router-acd36729.js";import{d as r,q as t}from"./runtime-core.esm-bundler-8c23b74b.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
