import{R as e}from"./vue-router-7d51514f.js";import{d as r,q as t}from"./runtime-core.esm-bundler-f902e13f.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
