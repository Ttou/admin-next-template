import{a as s,C as a}from"./Col-166ee151.js";import{w as o}from"./useConfigInject-bc8cb14d.js";const l=o(s),m=o(a);export{m as C,l as R};
