import{R as e}from"./vue-router-22a2ab70.js";import{d as r,f as t}from"./runtime-core.esm-bundler-d3f66853.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
