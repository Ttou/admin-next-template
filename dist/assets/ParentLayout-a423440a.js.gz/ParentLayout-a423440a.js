import{R as e}from"./vue-router-f551aed2.js";import{d as r,x as t}from"./runtime-core.esm-bundler-d9565f10.js";const n=r({name:"ParentLayout",render(){return t(e,null,null)}});export{n as default};
